
Traverse to the game through the following path- SnakeGame -> build -> Main.exe

Play the game by using the arrow keys to control the snake (a chain of white circles) to collect food (denoted by blue or red circles) while avoiding the boundaries of the map and the tail of the snake.