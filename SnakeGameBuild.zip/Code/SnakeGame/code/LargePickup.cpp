#include "LargePickup.h"

LargePickup::LargePickup(int x, int y, int color, Map* map) : Pickup(x, y, color, 3, map)
{
}