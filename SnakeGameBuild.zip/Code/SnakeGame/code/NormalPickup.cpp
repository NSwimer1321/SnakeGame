#include "NormalPickup.h"

NormalPickup::NormalPickup(int x, int y, int color, Map* map) : Pickup(x, y, color, 1, map)
{
    
}